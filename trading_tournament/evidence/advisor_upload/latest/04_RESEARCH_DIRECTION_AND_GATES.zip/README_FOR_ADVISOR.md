# 04_RESEARCH_DIRECTION_AND_GATES

        This advisor packet is research-only paper/demo evidence. It contains no broker integration, no live orders, no order placement, and no real-money recommendation.

        Review `PACKET_MANIFEST.json`, `SOURCE_PATHS.csv`, `ROW_COUNTS.csv`, and `SHA256SUMS.csv` before interpreting results.
