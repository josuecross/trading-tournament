# Open Questions For Advisor

    1. Which fixed-rule combination-design review should come first?
    2. Which correlation/co-movement diagnostics are required before the next historical research_sample?
    3. Are any blocked families worth gate-review work before more ETF diagnostics?
    4. Does the advisor agree that paper-forward checkpoint timing should not freeze historical research?
