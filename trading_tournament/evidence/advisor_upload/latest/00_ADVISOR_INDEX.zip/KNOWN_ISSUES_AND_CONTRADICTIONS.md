# Known Issues And Contradictions

    - Packet-level challenge finality can be incomplete while individual ETF benchmark-like family rows are exact. Read row-level finality columns.
    - A_ETF_sector_momentum and current_no_cash_proxy_alpha_AB have existing Backtester variant paths, but are not accepted as independent-family completed rows because the compact family challenge requires fresh-window rolling streams.
    - GLD has higher target rates than SPY_200d in exact family rows, but materially worse drawdown/stop behavior.
    - Crypto target potential, if present, is Tier 1 exploratory only and not candidate-grade.
