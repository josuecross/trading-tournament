# Advisor Executive State

    Created: 2026-06-19T02:34:58Z

    Boundary: research-only paper/demo evidence. No real-money recommendation, broker integration, live orders, order placement, or AI trading gate.

    Main goal: determine whether independent simulated $3,000 challenge accounts can reach +$300 or +$400 before a -$600 / -20% stop, while preserving evidence tier separation.

    Active paper-forward candidate: SPY_200d_trend_model, with frozen rules.

    Best exact family: family_broad_etf_spy200d_v1 / SPY_200d_trend_model.

    Best exploratory family: family_crypto_spot_buy_hold_equal_weight_v1 / crypto_buy_hold_equal_weight; exploratory evidence is non-final and Tier 1 only.

    Profit exploration accounting integrity: passed. Profit exploration decision-usable: True.

    Best profit exploration tradeoff: SPY_200d_trend_model / practical_leader.

    Strategy candidate queue exists: True.

    Highest priority queued candidates: qqq_spy_gld_ief_dual_momentum_v1, value_momentum_factor_etf_rotation_v1, sector_top2_momentum_simple_v1.

    Data-gated queued candidates: managed_futures_proxy_etf_trend_v1, commodity_basket_etf_momentum_v1, crypto_spot_tsmom_tier2_review_v1, individual_stock_momentum_gate1b_v1.

    Rejected/deferred queued candidates: options_futures_forex_intraday_blocked_reference_v1.

    Combo promotion review packet: evidence/promotion_reviews/combo_SPY200d_GLD_50_50_v1/latest; decision: promote_to_paper_forward_review.

    Generic promotion review packet: evidence/promotion_review/latest; decision: candidate_exhaustive_queue_count=0; candidate_exhaustive run: False.

    Combo paper-forward observation plan packet: evidence/paper_forward_observation_plans/combo_SPY200d_GLD_50_50_v1/latest; decision: approve_future_paper_forward_observation_activation_prompt.

    Combo paper-forward observation activation packet: evidence/paper_forward_observations/combo_SPY200d_GLD_50_50_v1/latest; status: active_paper_demo_observation.

    Combo rule-hash resolution packet: evidence/rule_hash_reviews/combo_SPY200d_GLD_50_50_v1/latest; decision: source_spec_reconstructed_hash_verified.

    QQQ implementation review packet: evidence/implementation_reviews/qqq_spy_gld_ief_dual_momentum_v1/latest; decision: approve_research_sample_implementation.

    Value/momentum factor ETF implementation review packet: evidence/implementation_reviews/value_momentum_factor_etf_rotation_v1/latest; decision: approve_research_sample_implementation.

    Sector top2 ETF implementation review packet: evidence/implementation_reviews/sector_top2_momentum_simple_v1/latest; decision: approve_research_sample_implementation_core_nine.

    Managed-futures proxy implementation review packet: evidence/implementation_reviews/managed_futures_proxy_etf_trend_v1/latest; decision: data_acquisition_required.

    Value/momentum factor ETF data acquisition review packet: evidence/data_acquisition_reviews/value_momentum_factor_etf_rotation_v1/latest; decision: conditional_pending_terms_or_api_key.

    Managed-futures proxy data acquisition review packet: evidence/data_acquisition_reviews/managed_futures_proxy_etf_trend_v1/latest; decision: acquisition_review_passed_create_provider_terms_review.

    Value/momentum factor ETF provider terms/security review packet: evidence/data_acquisition_reviews/value_momentum_factor_etf_rotation_v1/provider_terms_security_review/latest; decision: approve_future_yfinance_download_prompt.

    Managed-futures proxy provider terms/security review packet: evidence/data_acquisition_reviews/managed_futures_proxy_etf_trend_v1/provider_terms_security_review/latest; decision: approve_future_yfinance_download_prompt_dbmf_kmlm_only.

    Value/momentum factor ETF data acquisition run packet: evidence/data_acquisition_runs/value_momentum_factor_etf_rotation_v1/latest; status: data_quality_review_passed.

    Managed-futures proxy data acquisition run packet: evidence/data_acquisition_runs/managed_futures_proxy_etf_trend_v1/latest; status: data_quality_review_passed_methodology_review_required.

    Managed-futures proxy methodology review packet: evidence/methodology_reviews/managed_futures_proxy_etf_trend_v1/latest; decision: conditional_approval_short_history_label_required.

    Candidate testing triage packet: evidence/candidate_triage/latest; decision: triage_complete_no_new_candidate_exhaustive_additions.

    Historical research expansion packet: evidence/historical_research_expansion/latest; phase: historical_research_expansion_parallel_to_paper_demo_observation.

    Current-state research dashboard: evidence/research_state/latest; phase: historical_research_expansion_parallel_to_paper_demo_observation.

    Historical attribution diagnostics packet: evidence/research_diagnostics/latest; status: attribution_diagnostics_available.

    Individual stock momentum Gate 1B packet: evidence/research_memos/gate1b/individual_stock_momentum/latest; decision: conditional_pending_provider_cost_review.

    Individual stock momentum Gate 1C packet: evidence/research_memos/gate1c/individual_stock_momentum/latest; decision: conditional_choose_provider_before_data_acquisition.

    Individual stock momentum Gate 1D packet: evidence/research_memos/gate1d/individual_stock_momentum/latest; decision: choose_norgate_for_gate1e_acquisition_review.

    Individual stock momentum Gate 1E packet: evidence/research_memos/gate1e/individual_stock_momentum/latest; decision: blocked_no_local_norgate_access.

    Individual stock momentum Gate 1F Sharadar fallback packet: evidence/research_memos/gate1f/individual_stock_momentum/latest; decision: conditional_pending_package_and_terms_selection.

    Historical research queue reprioritization packet: evidence/research_memos/queue_reprioritization/latest; decision: choose_commodity_basket_etf_momentum_review; next family: commodity_basket_etf_momentum_v1; next action: create_commodity_basket_etf_momentum_review.

    Commodity basket ETF product/data review packet: evidence/research_memos/commodity_basket_etf_momentum/latest; decision: approve_data_acquisition_review; products: DBC, PDBC, COMT, GSG, USCI; next action: commodity_data_acquisition_review.

    Commodity basket ETF data acquisition review packet: evidence/data_acquisition_reviews/commodity_basket_etf_momentum_v1/latest; decision: conditional_pending_product_identity_terms_review; future download symbols approved: ; next action: product_identity_terms_review.

    Fast commodity exploratory acquisition packet: evidence/data_acquisition_runs/commodity_basket_fast_exploratory/latest; downloaded symbols: DBC, PDBC, COMT, GSG, USCI; failed symbols: ; raw OHLCV in advisor packet: False.

    Commodity basket exploratory screen packet: evidence/commodity_exploratory/latest; verdict: research_sample_candidate_risk_budget_breach; candidate_exhaustive run: False.

    Commodity Risk-Control Batch 1 packet: evidence/commodity_lab/risk_control_batch1/latest; decision: no_candidate_exhaustive_review; best candidate: combo_plus_commodity_basket_80_20_v1; candidate_exhaustive run: False.

    Commodity Risk-Control Batch 1 verdict audit packet: evidence/commodity_lab/risk_control_batch1_verdict_audit/latest; decision: more_diagnostics_required_before_candidate_exhaustive_decision; candidate_exhaustive run: False.

    Commodity Risk-Control Batch 1 diagnostics completion packet: evidence/commodity_lab/risk_control_batch1_diagnostics_completion/latest; decision: diagnostics_support_watchlist_only_for_combo_plus_commodity_80_20; candidate_exhaustive recommended: False; candidate_exhaustive run: False.

    Crypto spot fast acquisition/cache packet: evidence/data_acquisition_runs/crypto_spot_fast_exploratory/latest; status: cache_confirmed_no_download; cache-confirmed symbols: BTC-USD, ETH-USD; downloaded symbols: ; raw OHLCV in advisor packet: False.

    Crypto Spot Tier 2 Risk-Control Batch 1 packet: evidence/crypto_lab/tier2_risk_control_batch1/latest; decision: no_candidate_exhaustive_review; best candidate: combo_plus_crypto_spot_tsmom_90_10_v1; candidate_exhaustive run: False.

    Global multi-asset fast acquisition packet: evidence/data_acquisition_runs/global_multi_asset_fast_exploratory/latest; status: downloaded_missing_approved_symbols; cache-confirmed symbols: SPY, QQQ, GLD, IEF, BIL, DBC, PDBC, COMT, GSG, USCI, IWM, TLT; downloaded symbols: EFA, EEM; raw OHLCV in advisor packet: False.

    Global Multi-Asset ETF Fast Exploration Batch 1 packet: evidence/multi_asset_lab/fast_exploration_batch1/latest; decision: no_candidate_exhaustive_review; best candidate: global_multi_asset_tsmom_top2_v1; candidate_exhaustive run: False.

    Historical Combination Batch 1 packet: evidence/combination_lab/latest; verdict: completed_no_candidate_exhaustive_queue.
    Historical Combination Batch 1 verdict audit: evidence/combination_lab/batch1_verdict_audit/latest; verdict: verdict_labels_corrected_with_no_candidate_exhaustive_run.
    Historical Combination Batch 1 diagnostics completion: evidence/combination_lab/batch1_diagnostics_completion/latest; decision: diagnostics_support_short_history_watchlist_only.

    Current phase correction: active paper/demo observation does not freeze historical research; forward checkpoint timing only blocks forward-observation judgment.

    Blocked families: family_individual_stock_momentum_v1, family_options_directional_v1, family_options_premium_v1, family_futures_trend_following_v1, family_forex_momentum_carry_v1, family_intraday_orb_v1, family_volatility_products_v1, family_event_news_momentum_v1.

    Incomplete families: family_etf_sector_momentum_A_v1, family_etf_ab_no_cash_v1.

    consistency_status: passed

    Current known contradictions: none detected.

    Challenge summary internally consistent: True.

    Run-level and row-level finality clearly separated: True.

    Biggest evidence issue: A_ETF_sector_momentum and current_no_cash_proxy_alpha_AB are not accepted as completed independent-family rows unless a fresh-window exact rolling stream is exposed.

    Recommended next decision: create a combination-design implementation review or improve diagnostics; do not tune the active combo or replace SPY_200d.
