# Advisor Consistency Report

Created: 2026-06-19T11:39:01Z

Status: passed

Passed: True

Errors: 0

Warnings: 0

Advisor top-level files: 10

Challenge latest files: 10

Exact benchmark rows present: BIL_cash_proxy, SPY_200d_trend_model, SPY_buy_hold

Row-level exact evidence present: True

Exact family rows present: True

Run-level finality false detected: True

## Errors

- none

## Warnings

- none

This report is research-only audit metadata. It is not a trading signal or real-money recommendation.
