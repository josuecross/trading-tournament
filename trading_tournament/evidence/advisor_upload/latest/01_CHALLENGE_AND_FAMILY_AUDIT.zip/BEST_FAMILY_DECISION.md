# Best Family Decision

    The current exact independent-family packet ranks `family_broad_etf_spy200d_v1` as the best overall family tradeoff. GLD remains the highest exact target-rate family when present, but it carries materially worse drawdown/stop behavior than SPY_200d. A/A-B strategy-family rows remain incomplete unless a fresh-window exact rolling stream is exposed; no summary-metric approximation is used.

    This is research-only paper/demo evidence and not a real-money recommendation.
